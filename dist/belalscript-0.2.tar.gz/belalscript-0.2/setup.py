from setuptools import setup

setup(
     name='belalscript',    # This is the name of your PyPI-package.
     version='0.2',                          # Update the version number for new releases
     scripts=['belalscript']                  # The name of your scipt, and also the command you'll be using for calling it
)